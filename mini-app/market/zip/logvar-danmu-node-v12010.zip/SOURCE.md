# 源码与许可

本小程序包内的 `server/danmu-service.cjs` 是 **LogVar 弹幕 API 服务**（danmu_api）的打包产物。

- 项目：https://github.com/huangxd-/danmu_api
- 许可：**AGPL-3.0**，全文见同目录的 `LICENSE`
- 版本：v1.20.10
- 构建自 commit：`28673ac764485b0f37966779bc3b14e2b97d31aa`

## 取得对应源码

业务源码在上游仓库：

```bash
git clone https://github.com/huangxd-/danmu_api
cd danmu_api && git checkout 28673ac764485b0f37966779bc3b14e2b97d31aa
npm install
```

宿主适配层（把 node 的请求接到 `worker.js` 的 `handleRequest` 上、按宿主的
启动契约导出 `start/stop`）在 ant-video 仓库的
`mini-app/miniapps/logvar-danmu-node/` 目录里——本包用的就是那一份。

## 从源码重建本包

```bash
git clone https://github.com/ant-video/ant-video
cd ant-video/mini-app/miniapps/logvar-danmu-node
DANMU_API_DIR=<上一步的 danmu_api checkout> node build-miniapp-node.js
# 产物在 dist/miniapp-node/
```

## 与远程部署版的差别

打包时以下模块被换成了空实现（与 WebView 版保持一致，探针阶段先不恢复）：

- `ui/template.js`（自带 Web 配置页）、`bangumi-data-util.js`（bangumi 数据集）、
  `local-redis-util.js`、`dan-any.js`（多格式弹幕转换），外加 `redis` 包。

node 内置模块（fs / http / https / url / path / stream）在 Node 版里都是**真的**，
不像 WebView 版那样被替换。
