/**
 * 115网盘API封装
 * 协议参考：115driver / p115client / openclaw-skill-115pan
 */
(function () {
  'use strict';

  var API_BASE = 'https://web.api.115.com';
  var QR_BASE = 'https://qrcodeapi.115.com/api/1.0/web/1.0';

  /* Cookie管理 */
  function getCookie() {
    try {
      return JSON.parse(localStorage.getItem('pan115_cookie') || '{}');
    } catch (e) { return {}; }
  }
  function setCookie(cookie) {
    localStorage.setItem('pan115_cookie', JSON.stringify(cookie));
  }
  function clearCookie() {
    localStorage.removeItem('pan115_cookie');
  }
  function cookieString() {
    var c = getCookie();
    return Object.keys(c).map(function (k) { return k + '=' + c[k]; }).join('; ');
  }
  function isLoggedIn() {
    var c = getCookie();
    return !!(c.UID && c.CID && c.SEID);
  }

  /* 通用请求（用ant.request，不受CORS限制） */
  function request(url, options) {
    options = options || {};
    var headers = options.headers || {};
    headers['User-Agent'] = 'Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36';
    if (isLoggedIn()) {
      headers['Cookie'] = cookieString();
    }
    var reqOpts = {
      url: url,
      method: options.method || 'GET',
      headers: headers,
      timeout: options.timeout || 30000
    };
    if (options.data) reqOpts.data = options.data;

    if (window.ant && ant.request) {
      return ant.request(reqOpts).then(function (resp) {
        var body = resp.data || '';
        try { return JSON.parse(body); } catch (e) { return body; }
      });
    }
    return fetch(url, { method: reqOpts.method, headers: headers, body: options.data }).then(function (r) {
      return r.text().then(function (t) {
        try { return JSON.parse(t); } catch (e) { return t; }
      });
    });
  }

  /* ========== 扫码登录（正确协议） ========== */

  /**
   * 获取扫码登录token
   * GET https://qrcodeapi.115.com/api/1.0/web/1.0/token/
   * 返回 data: {uid, time, sign, qrcode}
   */
  function getQrToken() {
    return request('https://qrcodeapi.115.com/api/1.0/web/1.0/token/').then(function (resp) {
      if (resp && resp.state === false) throw new Error(resp.error || resp.error_msg || '获取token失败');
      var data = resp.data || resp;
      if (!data || !data.uid) throw new Error('获取token失败：返回数据异常');
      return data;
    });
  }

  /**
   * 获取二维码图片URL（用uid）
   * GET https://qrcodeapi.115.com/api/1.0/mac/1.0/qrcode?uid=xxx
   * 返回图片二进制，可直接用img.src显示
   */
  function getQrImageUrl(uid) {
    return 'https://qrcodeapi.115.com/api/1.0/mac/1.0/qrcode?uid=' + encodeURIComponent(uid) + '&_t=' + Date.now();
  }

  /**
   * 轮询扫码状态
   * GET https://qrcodeapi.115.com/get/status/?uid=xxx&time=xxx&sign=xxx
   * 返回 data: {status: 0/1/2/-1/-2}
   * 0=等待, 1=已扫码, 2=已登录, -1=已过期, -2=已取消
   */
  function checkQrStatus(tokenData) {
    var params = 'uid=' + encodeURIComponent(tokenData.uid) +
      '&time=' + encodeURIComponent(tokenData.time) +
      '&sign=' + encodeURIComponent(tokenData.sign);
    return request('https://qrcodeapi.115.com/get/status/?' + params).then(function (resp) {
      return resp && resp.data ? resp.data : resp;
    });
  }

  /**
   * 登录成功后获取cookie（绑定设备）
   * POST https://passportapi.115.com/app/1.0/{app}/1.0/login/qrcode/
   * 参数: app=web&account=uid
   * 返回 data: {cookie: {UID, CID, SEID, KID, ...}}
   */
  function postQrResult(uid, app) {
    app = app || 'web';
    var payload = 'app=' + encodeURIComponent(app) + '&account=' + encodeURIComponent(uid);
    return request('https://passportapi.115.com/app/1.0/' + app + '/1.0/login/qrcode/', {
      method: 'POST',
      data: payload,
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
    }).then(function (resp) {
      if (resp && resp.state === false) throw new Error(resp.error || resp.error_msg || '登录失败');
      return resp.data || resp;
    });
  }

  /**
   * 扫码登录完整流程（返回Promise，登录成功resolve cookie）
   * @param {function} onQrReady - 二维码就绪回调，传入二维码图片URL
   * @param {function} onStatus - 状态变化回调，传入状态文本
   * @param {number} timeout - 超时时间（毫秒），默认120秒
   */
  function qrLogin(onQrReady, onStatus, timeout) {
    timeout = timeout || 120000;
    var startTime = Date.now();
    var pollTimer = null;
    var tokenData = null;

    return new Promise(function (resolve, reject) {
      function cleanup() {
        if (pollTimer) { clearTimeout(pollTimer); pollTimer = null; }
      }
      function fail(msg) {
        cleanup();
        reject(new Error(msg));
      }

      getQrToken().then(function (data) {
        tokenData = data;
        var qrUrl = getQrImageUrl(data.uid);
        if (onQrReady) onQrReady(qrUrl, data);

        // 轮询状态
        function poll() {
          if (Date.now() - startTime > timeout) {
            fail('扫码超时，请重试');
            return;
          }
          checkQrStatus(tokenData).then(function (status) {
            var code = status.status !== undefined ? Number(status.status) : 0;
            if (code === 2) {
              // 已登录，获取cookie
              cleanup();
              if (onStatus) onStatus('登录中，获取凭证…');
              postQrResult(tokenData.uid, 'web').then(function (result) {
                var cookieData = (result && result.cookie) || result || {};
                var cookie = {};
                if (typeof cookieData === 'object') {
                  Object.keys(cookieData).forEach(function (k) {
                    cookie[k] = String(cookieData[k]);
                  });
                } else if (typeof cookieData === 'string') {
                  cookieData.split(';').forEach(function (pair) {
                    var kv = pair.trim().split('=');
                    if (kv[0]) cookie[kv[0]] = kv.slice(1).join('=');
                  });
                }
                if (cookie.UID || cookie.SEID) {
                  setCookie(cookie);
                  if (onStatus) onStatus('登录成功');
                  resolve(cookie);
                } else {
                  fail('登录成功但未获取到Cookie');
                }
              }).catch(function (e) {
                fail('获取Cookie失败：' + (e.message || e));
              });
            } else if (code === 1) {
              if (onStatus) onStatus('已扫码，请在手机上确认');
              pollTimer = setTimeout(poll, 2000);
            } else if (code === -1) {
              fail('二维码已过期，请重试');
            } else if (code === -2) {
              fail('扫码已取消');
            } else {
              if (onStatus) onStatus('等待扫码…');
              pollTimer = setTimeout(poll, 2000);
            }
          }).catch(function () {
            // 网络错误，继续轮询
            pollTimer = setTimeout(poll, 3000);
          });
        }
        poll();
      }).catch(function (e) {
        fail(e.message || '获取二维码失败');
      });
    });
  }

  /* ========== 文件操作 ========== */

  /**
   * 获取文件列表
   * @param {string} cid - 文件夹ID，根目录为0
   * @param {number} offset - 偏移量
   * @param {number} limit - 每页数量
   */
  function listFiles(cid, offset, limit) {
    cid = cid || 0;
    offset = offset || 0;
    limit = limit || 100;
    var url = API_BASE + '/files?aid=1&cid=' + cid + '&o=user_id&asc=0&offset=' + offset + '&show_dir=1&limit=' + limit + '&type=0&_t=' + Date.now();
    return request(url).then(function (resp) {
      if (resp && resp.state === false) throw new Error(resp.error_msg || '获取文件列表失败');
      return resp;
    });
  }

  /**
   * 搜索文件
   */
  function searchFiles(keyword, offset, limit) {
    offset = offset || 0;
    limit = limit || 50;
    var url = API_BASE + '/files/search?aid=1&search_value=' + encodeURIComponent(keyword) + '&offset=' + offset + '&limit=' + limit + '&_t=' + Date.now();
    return request(url).then(function (resp) {
      if (resp && resp.state === false) throw new Error(resp.error_msg || '搜索失败');
      return resp;
    });
  }

  /**
   * 获取文件下载链接
   * @param {string} pickcode - 文件的pickcode
   */
  function getDownloadUrl(pickcode) {
    var url = API_BASE + '/files/download?pickcode=' + encodeURIComponent(pickcode) + '&_t=' + Date.now();
    return request(url).then(function (resp) {
      if (resp && resp.state === false) throw new Error(resp.error_msg || '获取下载链接失败');
      // 返回格式可能是 {state: true, data: {url: '...'}} 或直接302
      if (resp && resp.data && resp.data.url) return resp.data.url;
      if (resp && resp.url) return resp.url;
      return resp;
    });
  }

  /**
   * 获取文件信息（含pickcode）
   */
  function getFileInfo(fileId) {
    var url = API_BASE + '/files/file_info?aid=1&file_id=' + fileId + '&_t=' + Date.now();
    return request(url).then(function (resp) {
      return resp && resp.data ? resp.data : resp;
    });
  }

  /* ========== 工具函数 ========== */

  /**
   * 判断是否是视频文件
   */
  function isVideoFile(name) {
    return /\.(mp4|mkv|avi|rmvb|rm|flv|wmv|m4v|ts|mov|mpg|mpeg|3gp|webm|m3u8)(\?|$)/i.test(name || '');
  }

  /**
   * 判断是否是音频文件
   */
  function isAudioFile(name) {
    return /\.(mp3|flac|wav|aac|ogg|wma|m4a|ape)(\?|$)/i.test(name || '');
  }

  /**
   * 判断是否是多媒体文件
   */
  function isMediaFile(name) {
    return isVideoFile(name) || isAudioFile(name);
  }

  /**
   * 格式化文件大小
   */
  function formatSize(bytes) {
    if (!bytes) return '';
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    if (bytes < 1024 * 1024 * 1024) return (bytes / 1024 / 1024).toFixed(1) + ' MB';
    return (bytes / 1024 / 1024 / 1024).toFixed(2) + ' GB';
  }

  // 暴露到全局
  window.Pan115 = {
    // 认证
    isLoggedIn: isLoggedIn,
    getCookie: getCookie,
    setCookie: setCookie,
    clearCookie: clearCookie,
    cookieString: cookieString,
    // 扫码登录
    getQrToken: getQrToken,
    getQrImageUrl: getQrImageUrl,
    checkQrStatus: checkQrStatus,
    qrLogin: qrLogin,
    // 文件
    listFiles: listFiles,
    searchFiles: searchFiles,
    getDownloadUrl: getDownloadUrl,
    getFileInfo: getFileInfo,
    // 工具
    isVideoFile: isVideoFile,
    isAudioFile: isAudioFile,
    isMediaFile: isMediaFile,
    formatSize: formatSize,
    request: request
  };
})();
