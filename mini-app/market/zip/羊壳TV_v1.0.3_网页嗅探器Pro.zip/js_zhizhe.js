WidgetMetadata = {
  id: "dev.zhizhewanshui.shop",
  title: "国产传媒",
  version: "1.3.0",
  requiredVersion: "0.0.1",
  description: "zhizhewanshui.shop WebView播放版",
  author: "Dev",
  site: "https://www.zhizhewanshui.shop",
  icon: "https://assets.vvebo.vip/scripts/icon.png",
  detailCacheDuration: 300,
  modules: [
    {
      id: "loadList",
      title: "最新影片",
      functionName: "loadList",
      cacheDuration: 1800,
      params: [
        {
          name: "type",
          title: "分类",
          type: "enumeration",
          enumOptions: [
            { title: "全部", value: "0" },
            { title: "在线国产", value: "1" },
            { title: "传媒剧情", value: "6" },
            { title: "国产主播", value: "7" },
            { title: "国产明星", value: "8" },
            { title: "抖阴视频", value: "9" },
            { title: "网爆黑料", value: "10" },
            { title: "网红头条", value: "11" },
            { title: "萝莉少女", value: "12" },
            { title: "欧美无码", value: "13" },
            { title: "日本无码", value: "14" },
            { title: "制服诱惑", value: "15" },
            { title: "强奸乱伦", value: "16" }
          ],
          value: "0"
        },
        { name: "page", title: "页码", type: "page" }
      ]
    }
  ],
  search: {
    title: "搜索",
    functionName: "searchVideos",
    params: [
      { name: "keyword", title: "关键词", type: "input" },
      { name: "page", title: "页码", type: "page" }
    ]
  }
};

const BASE = "https://www.zhizhewanshui.shop";

function abs(path) {
  if (!path) return "";
  if (path.startsWith("http")) return path;
  if (path.startsWith("//")) return "https:" + path;
  return BASE + (path.startsWith("/") ? path : "/" + path);
}

function vid(url) {
  if (!url) return null;
  const m = url.match(/\/detail\/id\/(\d+)/);
  return m ? m[1] : null;
}

function extractImage($el) {
  if (!$el || $el.length === 0) return "";
  const attrs = ["data-original", "data-src", "original-src", "src", "data-url"];
  for (const attr of attrs) {
    const val = $el.attr(attr);
    if (val && val.trim() && !val.startsWith("data:")) {
      return abs(val.trim());
    }
  }
  const style = $el.attr("style") || "";
  const bgMatch = style.match(/url\((["']?)([^"')]+)\1\)/);
  if (bgMatch) return abs(bgMatch[2]);
  return "";
}

// ========================
// 列表
// ========================
async function loadList(params = {}) {
  try {
    const page = Number(params.page || 1);
    const type = String(params.type || "0");

    let url;
    if (type === "0") {
      url = page === 1 ? BASE + "/" : `${BASE}/index.php/vod/type/id/0/page/${page}.html`;
    } else {
      url = page === 1
        ? `${BASE}/index.php/vod/type/id/${type}.html`
        : `${BASE}/index.php/vod/type/id/${type}/page/${page}.html`;
    }

    const res = await Widget.http.get(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Referer": BASE
      }
    });

    if (!res || !res.data) throw new Error("空响应");

    const html = String(res.data);
    const $ = Widget.html.load(html);
    const items = [];
    const seen = new Set();

    const listSelectors = [
      "#tpl-img-content > li",
      "ul.img-list-data > li",
      ".img-list-data > li",
      "ul.img-list-data li",
      "#tpl-img-content li"
    ];

    for (const sel of listSelectors) {
      const $lis = $(sel);
      if ($lis.length === 0) continue;

      $lis.each((_, li) => {
        const $li = $(li);
        const $a = $li.find("a[href*='detail/id/']").first();
        const href = $a.attr("href") || "";
        const id = vid(href);
        if (!id || seen.has(id)) return;
        seen.add(id);

        let poster = "";
        const $img = $li.find("img.content-img.lazy, img.lazy, img").first();
        poster = extractImage($img);

        let title = "";
        const $titleEl = $li.find("h3.text-ellipsis").first();
        if ($titleEl.length > 0) title = $titleEl.text().trim();
        if (!title) title = ($a.attr("title") || "").trim();
        if (!title) title = $li.find("h3, .title, .name").first().text().trim();

        if (title && title.length > 0) {
          items.push({
            id: `zzws:${id}`,
            type: "url",
            title: title,
            posterPath: poster,
            link: `zzws:${id}`
          });
        }
      });

      if (items.length > 0) break;
    }

    if (items.length === 0) {
      $("a[href*='detail/id/']").each((_, el) => {
        const $a = $(el);
        const href = $a.attr("href") || "";
        const id = vid(href);
        if (!id || seen.has(id)) return;
        seen.add(id);

        const $li = $a.closest("li, .item, div").first();
        const $img = $a.find("img").length > 0 ? $a.find("img").first() : $li.find("img").first();
        const poster = extractImage($img);
        const title = ($a.attr("title") || $li.find("h3, .title").first().text() || $a.text() || "").trim();

        if (title) {
          items.push({
            id: `zzws:${id}`,
            type: "url",
            title: title,
            posterPath: poster,
            link: `zzws:${id}`
          });
        }
      });
    }

    return items;
  } catch (err) {
    console.error("[loadList]", err.message || err);
    throw err;
  }
}

// ========================
// 详情页 - WebView版（不解析m3u8，直接给播放页）
// ========================
async function loadDetail(link) {
  try {
    if (!link || !String(link).startsWith("zzws:")) return null;
    const raw = String(link).replace("zzws:", "");
    const id = raw.split(":")[0];
    const detailUrl = `${BASE}/index.php/vod/detail/id/${id}.html`;

    const res = await Widget.http.get(detailUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Referer": BASE
      }
    });

    if (!res || !res.data) return null;

    const html = String(res.data);
    const $ = Widget.html.load(html);

    const title = $("h1").first().text().trim()
      || $(".title").first().text().trim()
      || $(".vod-h1").first().text().trim()
      || "未知标题";

    const desc = $(".desc, .sketch, .vod-content, .stui-content__desc, .hl-content-text, .detail-info").first().text().trim();

    let poster = "";
    $(".stui-content__thumb img, .vod-n-img img, .myui-content__thumb img, .poster img, .hl-lazy, .detail-pic img, .tupian-pic img").each((_, el) => {
      if (poster) return;
      poster = extractImage($(el));
    });

    // 播放列表 - 直接给播放页URL，App用WebView打开
    const episodeItems = [];
    const playSeen = new Set();

    const playlistSelectors = [
      ".stui-content__playlist",
      ".playlist",
      ".myui-content__playlist",
      ".hl-plays-list",
      ".playlink",
      ".play-btn",
      ".play_list",
      ".stui-play__list",
      ".vod-play-list",
      ".playlist-box"
    ];

    for (const sel of playlistSelectors) {
      const $box = $(sel);
      if ($box.length === 0) continue;

      $box.find("a").each((idx, el) => {
        const $a = $(el);
        const href = $a.attr("href") || "";
        if (!href) return;

        const isPlay = href.includes("/play/") || href.includes("/vodplay/");
        if (!isPlay) return;
        if (playSeen.has(href)) return;
        playSeen.add(href);

        const epTitle = $a.text().trim() || $a.attr("title") || `第${idx + 1}集`;
        const playPageUrl = abs(href);

        episodeItems.push({
          id: `zzws:${id}:ep:${idx}`,
          type: "url",
          title: epTitle,
          videoUrl: playPageUrl,   // 播放页完整URL
          link: `zzws:${id}:ep:${idx}`,
          playerType: "app"         // WebView打开，站点播放器自己工作
        });
      });

      if (episodeItems.length > 0) break;
    }

    // 兜底
    if (episodeItems.length === 0) {
      $("a[href*='/play/'], a[href*='/vodplay/']").each((idx, el) => {
        const $a = $(el);
        const href = $a.attr("href") || "";
        if (!href || playSeen.has(href)) return;
        playSeen.add(href);

        const epTitle = $a.text().trim() || $a.attr("title") || `第${idx + 1}集`;
        const playPageUrl = abs(href);

        episodeItems.push({
          id: `zzws:${id}:ep:${idx}`,
          type: "url",
          title: epTitle,
          videoUrl: playPageUrl,
          link: `zzws:${id}:ep:${idx}`,
          playerType: "app"
        });
      });
    }

    // 第一集播放页作为顶层videoUrl
    const firstVideoUrl = episodeItems.length > 0 ? episodeItems[0].videoUrl : "";

    // 相关推荐
    const relatedItems = [];
    const relSeen = new Set();
    $("a[href*='detail/id/']").each((_, el) => {
      const $a = $(el);
      const href = $a.attr("href") || "";
      const rid = vid(href);
      if (!rid || rid === id || relSeen.has(rid)) return;
      relSeen.add(rid);

      const $container = $a.closest("li, .item, div").first();
      const $img = $a.find("img").length > 0 ? $a.find("img").first() : $container.find("img").first();
      const rPoster = extractImage($img);
      const rTitle = ($a.attr("title") || $container.find("h3, .title, .name").first().text() || $a.text() || "").trim();

      if (rTitle) {
        relatedItems.push({
          id: `zzws:${rid}`,
          type: "url",
          title: rTitle,
          posterPath: rPoster,
          link: `zzws:${rid}`
        });
      }
    });

    return {
      id: link,
      type: "url",
      title: title,
      posterPath: poster,
      description: desc,
      videoUrl: firstVideoUrl || undefined,
      link: link,
      episodeItems: episodeItems.length > 0 ? episodeItems : undefined,
      relatedItems: relatedItems.length > 0 ? relatedItems : undefined,
      playerType: "app"   // 统一用WebView
    };
  } catch (err) {
    console.error("[loadDetail]", err.message || err);
    return null;
  }
}

// ========================
// 搜索
// ========================
async function searchVideos(params = {}) {
  try {
    const keyword = params.keyword || "";
    const page = Number(params.page || 1);
    if (!keyword.trim()) return [];

    let url;
    if (page === 1) {
      url = `${BASE}/index.php/vod/search.html?wd=${encodeURIComponent(keyword)}`;
    } else {
      url = `${BASE}/index.php/vod/search/page/${page}/wd/${encodeURIComponent(keyword)}.html`;
    }

    const res = await Widget.http.get(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Referer": BASE
      }
    });

    if (!res || !res.data) throw new Error("空响应");

    const html = String(res.data);
    const $ = Widget.html.load(html);
    const items = [];
    const seen = new Set();

    $("a[href*='detail/id/']").each((_, el) => {
      const $a = $(el);
      const href = $a.attr("href") || "";
      const id = vid(href);
      if (!id || seen.has(id)) return;
      seen.add(id);

      const $container = $a.closest("li, .item, div").first();
      const $img = $a.find("img").length > 0 ? $a.find("img").first() : $container.find("img").first();
      const poster = extractImage($img);
      const title = ($a.attr("title") || $container.find("h3, .title").first().text() || $a.text() || "").trim();

      if (title) {
        items.push({
          id: `zzws:${id}`,
          type: "url",
          title: title,
          posterPath: poster,
          link: `zzws:${id}`
        });
      }
    });

    return items;
  } catch (err) {
    console.error("[searchVideos]", err.message || err);
    throw err;
  }
}
