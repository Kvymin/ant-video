/**
 * JS源运行时沙箱
 * 模拟TVBox/四壳JS源运行时的全局API（Java.req等）
 * 支持标准WV格式JS源：homeContent/homeVideoContent/categoryContent/detailContent/playerContent/searchContent
 */
(function () {
  'use strict';

  /**
   * 创建一个JS源沙箱实例
   * @param {string} sourceCode - JS源代码
   * @returns {object} 沙箱实例，含exec方法和接口缓存
   */
  function createSandbox(sourceCode) {
    var api = null;
    var sandboxJava = createJavaApi();

    /**
     * 执行JS源代码，提取标准接口函数
     */
    function ensureApi() {
      if (api) return api;
      try {
        // 在源代码末尾追加导出语句，把标准接口函数返回出来
        var exportCode = sourceCode + '\n;return {' +
          'homeContent: (typeof homeContent!=="undefined")?homeContent:null,' +
          'homeVideoContent: (typeof homeVideoContent!=="undefined")?homeVideoContent:null,' +
          'categoryContent: (typeof categoryContent!=="undefined")?categoryContent:null,' +
          'detailContent: (typeof detailContent!=="undefined")?detailContent:null,' +
          'playerContent: (typeof playerContent!=="undefined")?playerContent:null,' +
          'searchContent: (typeof searchContent!=="undefined")?searchContent:null,' +
          'rule: (typeof rule!=="undefined")?rule:null' +
        '};';
        var fn = new Function('Java', 'log', 'js2Proxy', 'js2json', 'setTimeout', 'clearTimeout', 'setInterval', 'clearInterval', exportCode);
        var result = fn(sandboxJava, jsLog, js2Proxy, js2json, setTimeout, clearTimeout, setInterval, clearInterval);
        api = result || {};
      } catch (e) {
        console.error('[JsSourceRuntime] 执行JS源失败:', e);
        api = {};
      }
      return api;
    }

    /**
     * 调用接口函数，统一处理同步/异步返回
     */
    function call(fnName) {
      var args = Array.prototype.slice.call(arguments, 1);
      var iface = ensureApi();
      var fn = iface[fnName];
      if (!fn) return Promise.reject(new Error('JS源未实现接口: ' + fnName));
      try {
        var ret = fn.apply(null, args);
        if (ret && typeof ret.then === 'function') {
          return ret;
        }
        return Promise.resolve(ret);
      } catch (e) {
        return Promise.reject(e);
      }
    }

    return {
      home: function () { return call('homeContent'); },
      homeVideo: function () { return call('homeVideoContent'); },
      category: function (tid, pg) { return call('categoryContent', tid, pg); },
      detail: function (ids) { return call('detailContent', ids); },
      play: function (flag, id) { return call('playerContent', flag, id); },
      search: function (key, quick, pg) { return call('searchContent', key, quick, pg); },
      getApi: ensureApi
    };
  }

  /**
   * 创建Java API对象（模拟TVBox运行时）
   */
  function createJavaApi() {
    return {
      /**
       * HTTP请求
       * Java.req(url) 或 Java.req({url, method, headers, data})
       * 返回 {body, headers, code}
       */
      req: function (urlOrOpts) {
        var opts = typeof urlOrOpts === 'string' ? { url: urlOrOpts } : urlOrOpts;
        var url = opts.url || '';
        var method = opts.method || 'GET';
        var headers = opts.headers || {};
        var data = opts.data || opts.body || null;

        // 默认UA
        if (!headers['User-Agent'] && !headers['user-agent']) {
          headers['User-Agent'] = 'Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36';
        }

        var reqOpts = {
          url: url,
          method: method,
          headers: headers,
          timeout: opts.timeout || 30000
        };
        if (data) reqOpts.data = data;

        // 用ant.request（宿主提供，不受CORS限制）
        if (window.ant && ant.request) {
          return ant.request(reqOpts).then(function (resp) {
            return {
              body: resp.data || '',
              headers: resp.headers || {},
              code: resp.statusCode || 200
            };
          }).catch(function (e) {
            return { body: '', headers: {}, code: 0, error: e };
          });
        }
        // 回退到fetch（浏览器环境，受CORS限制）
        return fetch(url, { method: method, headers: headers, body: data }).then(function (resp) {
          return resp.text().then(function (text) {
            return { body: text, headers: {}, code: resp.status };
          });
        }).catch(function (e) {
          return { body: '', headers: {}, code: 0, error: e };
        });
      },

      /**
       * URL编码
       */
      url: function (str) {
        return encodeURI(str || '');
      },

      /**
       * 加载字符串（GET请求返回文本）
       */
      loadStr: function (url) {
        return this.req(url).then(function (resp) {
          return resp.body || '';
        });
      },

      /**
       * 拼接URL
       */
      joinUrl: function (base, rel) {
        if (!rel) return base;
        if (/^https?:/i.test(rel)) return rel;
        if (rel.indexOf('//') === 0) return 'https:' + rel;
        try {
          return new URL(rel, base).href;
        } catch (e) {
          if (rel.charAt(0) === '/') {
            var m = base.match(/^(https?:\/\/[^/]+)/i);
            return (m ? m[1] : '') + rel;
          }
          return base.replace(/[^/]*$/, '') + rel;
        }
      },

      /**
       * 加载JSON
       */
      getJSON: function (url) {
        return this.req(url).then(function (resp) {
          try { return JSON.parse(resp.body); } catch (e) { return null; }
        });
      }
    };
  }

  /* 工具函数 */
  function jsLog(msg) {
    console.log('[JS源]', msg);
  }
  function js2Proxy(obj) {
    return obj;
  }
  function js2json(obj) {
    if (obj === null || obj === undefined) return obj;
    return JSON.parse(JSON.stringify(obj));
  }

  /**
   * 已加载的JS源缓存
   */
  var sourceCache = {};

  /**
   * 加载并缓存JS源
   * @param {string} key - 源标识
   * @param {string} code - JS源代码
   * @returns {object} 沙箱实例
   */
  function loadSource(key, code) {
    if (!sourceCache[key]) {
      sourceCache[key] = createSandbox(code);
    }
    return sourceCache[key];
  }

  /**
   * 从URL加载JS源
   */
  function loadSourceFromUrl(key, url) {
    if (sourceCache[key]) return Promise.resolve(sourceCache[key]);
    var javaApi = createJavaApi();
    return javaApi.loadStr(url).then(function (code) {
      return loadSource(key, code);
    });
  }

  // 暴露到全局
  window.JsSourceRuntime = {
    createSandbox: createSandbox,
    loadSource: loadSource,
    loadSourceFromUrl: loadSourceFromUrl,
    createJavaApi: createJavaApi
  };
})();
