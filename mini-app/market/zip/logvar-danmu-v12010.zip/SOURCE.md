# 源码与许可

本小程序包内的 `danmu-service.js` 是 **LogVar 弹幕 API 服务**（danmu_api）的打包产物。

- 项目：https://github.com/huangxd-/danmu_api
- 许可：**AGPL-3.0**，全文见同目录的 `LICENSE`
- 版本：v1.20.10
- 构建自 commit：`28673ac764485b0f37966779bc3b14e2b97d31aa`

## 取得对应源码

```bash
git clone https://github.com/huangxd-/danmu_api
cd danmu_api && git checkout 28673ac764485b0f37966779bc3b14e2b97d31aa
npm install
npm run build-miniapp        # 产物在 dist/miniapp/
```

宿主适配层（把 `fetch` 接到 `ant.request`、用 `ant.serve` 接住宿主请求）在上游仓库的
`miniapp/` 目录里，打包脚本是 `build-miniapp.js`，两者都在同一份 AGPL-3.0 之下。

## 与远程部署版的差别

打包时以下模块被换成了空实现（都依赖磁盘或 Node 网络栈，WebView 里没有对应能力）：
`ui/template.js`（自带 Web 配置页）、`bangumi-data-util.js`（bangumi 数据集）、
`local-redis-util.js`、`dan-any.js`（多格式弹幕转换）。详见 `build-miniapp.js` 里的 `stubs`。
